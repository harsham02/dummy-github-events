package com.petzey.exception;

public class InvalidDataExceptuion extends Exception {

	public InvalidDataExceptuion() {
		super();

	}

	public InvalidDataExceptuion(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

	public InvalidDataExceptuion(String message, Throwable cause) {
		super(message, cause);
	
	}

	public InvalidDataExceptuion(String message) {
		super(message);
	
	}

	public InvalidDataExceptuion(Throwable cause) {
		super(cause);
	
	}

}
