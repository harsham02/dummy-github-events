package com.petzey.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor	
@AllArgsConstructor	
@Data
public class ErrorHandler {

private final static  String status = "ERROR";
private int code;
private String message;

}
