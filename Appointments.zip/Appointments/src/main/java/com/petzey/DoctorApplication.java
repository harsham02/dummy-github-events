package com.petzey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.petzey.mapper.DoctorMapper;
import com.petzey.mapper.DoctorMapperImpl;

@SpringBootApplication
public class DoctorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorApplication.class, args);
	}
	@Bean
	public DoctorMapper getDoctorMapper() {
		return new DoctorMapperImpl();
	}

}
