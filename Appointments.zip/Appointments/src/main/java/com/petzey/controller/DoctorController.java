package com.petzey.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.petzey.dto.DoctorDto;
import com.petzey.entities.Doctor;
import com.petzey.service.DoctorService;

@RestController("/Doctor")
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;
	
	@PostMapping("/addnew")
	public ResponseEntity<Doctor> addNewDoctor(@RequestBody Doctor doctor){
		return new ResponseEntity<>(doctorService.addNewDoctor(doctor),HttpStatus.OK);
	}
	
	@GetMapping("/getAllDoctors")
	public ResponseEntity<List<DoctorDto>> getAllDoctors(){
		return new ResponseEntity<>(doctorService.getAllDoctors(),HttpStatus.OK);
	}
	
	@GetMapping("/get/byName")
	public ResponseEntity<Doctor> getDoctorByName(@PathParam (value="doctorName") String doctorName){
		return new ResponseEntity<>(doctorService.findByName(doctorName),HttpStatus.OK);
	}
}
 