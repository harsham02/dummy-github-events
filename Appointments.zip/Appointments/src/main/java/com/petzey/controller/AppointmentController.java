package com.petzey.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.petzey.dto.AppointmentDto;
import com.petzey.entities.Appointment;
import com.petzey.exception.ErrorHandler;
import com.petzey.exception.InvalidDataExceptuion;
import com.petzey.service.AppointmentService;

@RestController("/Appointment")
public class AppointmentController {
	
	@Autowired
	private AppointmentService appointmentService;
	
	@PostMapping("/addnewAppointment")
	public ResponseEntity<?> post(@RequestBody Appointment appointment){
		ResponseEntity<?> response;
		try {
	 response = new ResponseEntity<>(appointmentService.addNewAppointment(appointment),HttpStatus.OK);
		}catch(InvalidDataExceptuion e)
		{
			response = new ResponseEntity<>(new ErrorHandler(HttpStatus.NOT_FOUND.value(),e.getMessage()),HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
	@GetMapping("/countStatus/confirmed")
	public ResponseEntity<Long> get(){
	 	String status="confirmed";
		return new ResponseEntity<>(appointmentService.getCountOfStatus(status),HttpStatus.OK);
		
	}
	@GetMapping("/countStatus/cancelled")
	public ResponseEntity<Long> getCancelled(){
		String status="cancelled";
		return new ResponseEntity<>(appointmentService.getCountOfStatus(status),HttpStatus.OK);
		
	}
	@GetMapping("countstatus/closed")
	public ResponseEntity<Long> getClosed(){
		String status="closed";
		return new ResponseEntity<>(appointmentService.getCountOfStatus(status),HttpStatus.OK);
		
	}
	@GetMapping("/totalNumber")
	public ResponseEntity<Integer> getTotal(){
		return new ResponseEntity<>(appointmentService.getTotalAppointmentCount(),HttpStatus.OK);
		
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<AppointmentDto>> getAll(){
		return new ResponseEntity<>(appointmentService.getAllAppointment(),HttpStatus.OK);
	}
	
	
}
