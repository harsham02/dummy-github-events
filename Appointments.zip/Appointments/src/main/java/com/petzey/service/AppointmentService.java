package com.petzey.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.petzey.dto.AppointmentDto;
import com.petzey.entities.Appointment;
import com.petzey.exception.InvalidDataExceptuion;

@Service
public interface AppointmentService {
	
	public Appointment addNewAppointment(Appointment appointment) throws InvalidDataExceptuion;
	
	public long getCountOfStatus(String status);
	
	public int getTotalAppointmentCount();
	
	public List<AppointmentDto> getAllAppointment();
}
