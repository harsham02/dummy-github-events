package com.petzey.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petzey.dto.DoctorDto;
import com.petzey.entities.Doctor;
import com.petzey.mapper.DoctorMapper;
import com.petzey.repository.DoctorRepository;
import com.petzey.service.DoctorService;
@Service
public class DoctorServiceImpl implements DoctorService {
	
	@Autowired
	private DoctorRepository doctorRepository;
	@Autowired
	private DoctorMapper mapper;
	
	private static final Logger log = LoggerFactory.getLogger(DoctorServiceImpl.class);
	
	@Override
	public Doctor addNewDoctor(Doctor doctor) {

		doctorRepository.save(doctor);
		return doctor;
	}
	
 	@Override
	public Doctor findByName(String doctorName) {	
		return doctorRepository.getBydoctorName(doctorName);
	}
 	
	@Override
	public List<DoctorDto> getAllDoctors() {
		log.info("Getting All Doctors");
		List<Doctor> listDoctor=doctorRepository.findAll();
		List<DoctorDto> listDoctorDto=new ArrayList<>();
		DoctorDto doctorDto ;
		for(Doctor doctor:listDoctor) {
			doctorDto=mapper.converttoDto(doctor);
			listDoctorDto.add(doctorDto);
		}
		return listDoctorDto;
	}

}
