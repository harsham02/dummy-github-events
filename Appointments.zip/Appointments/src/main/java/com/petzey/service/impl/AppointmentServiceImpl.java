package com.petzey.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petzey.dto.AppointmentDto;
import com.petzey.entities.Appointment;
import com.petzey.entities.Doctor;
import com.petzey.exception.InvalidDataExceptuion;
import com.petzey.mapper.DoctorMapper;
import com.petzey.repository.AppointmentRepository;
import com.petzey.repository.DoctorRepository;
import com.petzey.service.AppointmentService;


@Service
public class AppointmentServiceImpl implements AppointmentService{
	
   @Autowired
   private DoctorRepository doctorRepository;
	
   @Autowired
   private AppointmentRepository appointmentRepository;
	
   @Autowired
   private DoctorMapper mapper;
	
   private static final Logger log = LoggerFactory.getLogger(AppointmentServiceImpl.class);
    
@Override
	public Appointment addNewAppointment(Appointment appointment) throws InvalidDataExceptuion {
		log.info("Adding new Appointment");
		Doctor doctor=doctorRepository.getBydoctorName(appointment.getDoctorName());
		if( doctor!=null) {
		
			doctor.getAppointments().add(appointment);
		 	doctorRepository.save(doctor);
		 	return appointment;
		} 
		 
		 else {
			log.error("Invalid Data Entered to save Code");
			throw new InvalidDataExceptuion("Invalid Data Entered to save Code");
		}
	}
	@Override
	public long getCountOfStatus(String status) {
		return appointmentRepository.count();
	}
	@Override
	public int getTotalAppointmentCount() {
		return appointmentRepository.findAll().size();
	}
	@Override
	public List<AppointmentDto> getAllAppointment() {
		log.info("Getting all Appointments");
		List<Appointment> listAppointment=appointmentRepository.findAll();
		List<AppointmentDto> listAppointDto=new ArrayList<>();
		AppointmentDto appointmentDto;
		for(Appointment appointment:listAppointment) {
			appointmentDto=mapper.converttoDto(appointment);
			listAppointDto.add(appointmentDto);
		}
		return listAppointDto;
	}

}
