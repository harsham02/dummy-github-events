package com.petzey.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.petzey.dto.DoctorDto;
import com.petzey.entities.Doctor;

@Service
public interface DoctorService {
	
	public Doctor addNewDoctor(Doctor doctor);
	public Doctor findByName(String doctorName);
	public List<DoctorDto> getAllDoctors();
}
  