package com.petzey;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.petzey.dto.AppointmentDto;
import com.petzey.dto.DoctorDto;
import com.petzey.entities.Appointment;
import com.petzey.entities.Doctor;
import com.petzey.service.AppointmentService;
import com.petzey.service.DoctorService;

@WebMvcTest
class DoctorApplicationTests {	

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private DoctorService doctorService;
	
	@MockBean
	private AppointmentService appointmentService;
	
 private static ObjectMapper mapper = new ObjectMapper();
 
 @Test
 void AddDoctor() throws Exception {
	 
	 Doctor doctor = new Doctor();
	 
	 doctor.setDoctorId(1);
	 doctor.setDoctorName("harsha");
	 doctor.setEmail("harsha@gmail.com"); 
	 doctor.setMobile("8987969877");
	 doctor.setNpiNo("58790");
	 doctor.setSpeciality("Eye");
	 doctor.setClinic("harsh clinic");
	 Mockito.when(doctorService.addNewDoctor(ArgumentMatchers.any())).thenReturn(doctor);
	 String json = mapper.writeValueAsString(doctor);
	 mockMvc.perform(post("/addnew").contentType(MediaType.APPLICATION_PROBLEM_JSON).characterEncoding("utf-8")
		.content(json).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
	    .andExpect(jsonPath("$.doctorId", Matchers.equalTo(1)))
	    .andExpect(jsonPath("$.doctorName", Matchers.equalTo("harsha")))
	    .andExpect(jsonPath("$.email", Matchers.equalTo("harsha@gmail.com")))
	    .andExpect(jsonPath("$.mobile", Matchers.equalTo("8987969877")))
	    .andExpect(jsonPath("$.npiNo", Matchers.equalTo("58790")))
	    .andExpect(jsonPath("$.speciality", Matchers.equalTo("Eye")))
	    .andExpect(jsonPath("$.clinic", Matchers.equalTo("harsh clinic")));
 }
 
 @Test
 void testAddNewAppointment() throws Exception
 {
	Appointment app = new Appointment(); 
	
	app.setAppointmentId(1);
	app.setDoctorName("harsha");
	app.setAppointmentStatus("Confirmed");
	app.setPetIssues("Skin problem");
	app.setPet("manasa");
	app.setPetParent("Manasa C");
	app.setReasonForVisit("consulting Doctor");
    Mockito.when(appointmentService.addNewAppointment(ArgumentMatchers.any())).thenReturn(app);
	String json = mapper.writeValueAsString(app);
    mockMvc.perform(post("/addnewAppointment").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
	 .content(json).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
	 .andExpect(jsonPath("$.appointmentId", Matchers.equalTo(1)))
	 .andExpect(jsonPath("$.appointmentStatus", Matchers.equalTo("Confirmed")))
	 .andExpect(jsonPath("$.doctorName", Matchers.equalTo("harsha")))
	 .andExpect(jsonPath("$.petIssues", Matchers.equalTo("Skin problem")))
	 .andExpect(jsonPath("$.pet", Matchers.equalTo("manasa")))
	 .andExpect(jsonPath("$.petParent", Matchers.equalTo("Manasa C")))
	 .andExpect(jsonPath("$.reasonForVisit", Matchers.equalTo("consulting Doctor")));	       
 }  
 
    @Test
     void testGetAllDoctors() throws Exception {
        List<DoctorDto> doctors = new ArrayList<>();
        DoctorDto doctor = new DoctorDto();
        doctor.setDoctorName("harsha");
        doctor.setMobile("7465887865");
        doctor.setSpeciality("eye");
        doctors.add(doctor);
        Mockito.when(doctorService.getAllDoctors()).thenReturn(doctors);
        mockMvc.perform(get("/getAllDoctors")).andExpect(status().isOk())
        .andExpect(jsonPath("$", Matchers.hasSize(1)))
        .andExpect(jsonPath("$[0].doctorName", Matchers.equalTo("harsha")))
        .andExpect(jsonPath("$[0].mobile", Matchers.equalTo("7465887865")))
        .andExpect(jsonPath("$[0].speciality", Matchers.equalTo("eye")));
    }
    @Test
    void testGetAllAppointments() throws Exception {
       List<AppointmentDto> apps = new ArrayList<>();
       AppointmentDto app = new AppointmentDto();
       
       app.setPet("manasa");
       app.setPetParent("MANASA");
       apps.add(app);
       Mockito.when(appointmentService.getAllAppointment()).thenReturn(apps);
       mockMvc.perform(get("/all")).andExpect(status().isOk())
       .andExpect(jsonPath("$", Matchers.hasSize(1)))
       .andExpect(jsonPath("$[0].pet", Matchers.equalTo("manasa")))
       .andExpect(jsonPath("$[0].petParent", Matchers.equalTo("MANASA")));
       
   }
    
    @Test
    void testGetCountStatus2() throws Exception {
    	
        List<Appointment> appointments = new ArrayList<>();

        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1);
        appointment.setDoctorName("HARSHA");
        appointment.setPet("MANASA");
        appointment.setPetIssues("Fever");
        appointment.setReasonForVisit("Checkup");
        appointment.setAppointmentStatus("Cancelled");
     
        appointment.setAppointmentId(2);
        appointment.setDoctorName("HARSHA");
        appointment.setPet("MANASA");
        appointment.setPetIssues("Fever");
        appointment.setReasonForVisit("Checkup");
        appointment.setAppointmentStatus("Cancelled");
        
        appointments.add(appointment);
        appointments.add(appointment);
        String json = mapper.writeValueAsString(appointments);

        Mockito.when(appointmentService.getCountOfStatus(ArgumentMatchers.any())).thenReturn((long) 2);
         mockMvc.perform(get("/countStatus/cancelled").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
                 .content(json).accept(MediaType.APPLICATION_JSON))
                 .andExpect(status().isOk())
                 .andExpect(jsonPath("$", Matchers.equalTo(appointments.size())));
         
    }
    
    @Test
    void testGetCountStatus() throws Exception {
    	
        List<Appointment> appointments = new ArrayList<>();

        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1);
        appointment.setDoctorName("HARSHA");
        appointment.setPet("MANASA");
        appointment.setPetIssues("Fever");
        appointment.setReasonForVisit("Checkup");
        appointment.setAppointmentStatus("Confirmed");
     
        appointment.setAppointmentId(2);
        appointment.setDoctorName("HARSHA");
        appointment.setPet("MANASA");
        appointment.setPetIssues("Fever");
        appointment.setReasonForVisit("Checkup");
        appointment.setAppointmentStatus("Confirmed");
        
        appointments.add(appointment);
        appointments.add(appointment);
        String json = mapper.writeValueAsString(appointments);

        Mockito.when(appointmentService.getCountOfStatus(ArgumentMatchers.any())).thenReturn((long) 2);
         mockMvc.perform(get("/countStatus/confirmed").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
                 .content(json).accept(MediaType.APPLICATION_JSON))
                 .andExpect(status().isOk())
                 .andExpect(jsonPath("$", Matchers.equalTo(appointments.size())));
         
    }
//    @Test
//    void testGetCountStatus3() throws Exception {
//    	
//        List<Appointment> appointments = new ArrayList<>();
//
//        Appointment appointment = new Appointment();
//        appointment.setAppointmentId(1);
//        appointment.setDoctorName("HARSHA");
//        appointment.setPet("MANASA");
//        appointment.setPetIssues("Fever");
//        appointment.setReasonForVisit("Checkup");
//        appointment.setAppointmentStatus("Closed");
//            
//        appointments.add(appointment);
//        String json = mapper.writeValueAsString(appointments);
//
//        Mockito.when(appointmentService.getCountOfStatus(ArgumentMatchers.any())).thenReturn((long) 1);
//         mockMvc.perform(get("/countStatus/closed").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
//             .content(json).accept(MediaType.APPLICATION_JSON))
//             .andExpect(status().isOk())
//             .andExpect(jsonPath("$", Matchers.equalTo(appointments.size())));       
//    }
    
}
